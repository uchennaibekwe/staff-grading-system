<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Add Entry</h1>
        </div>
    </div>
    <?php echo $__env->make("notification", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /.row -->
    <div class="row">
        <form role="form" action="<?php echo e(route('entries.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    User Information
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-12">
                                <div class="form-group">
                                    <label>Name</label>
                                    <input name="name" value="<?php echo e(old('name')); ?>" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label>Email</label>
                                    <input name="email" value="<?php echo e(old('email')); ?>"  class="form-control">
                                </div>
                                <div class="form-group">
                                    <label>Phone</label>
                                    <input name="phone" value="<?php echo e(old('phone')); ?>"  class="form-control" type="number">
                                </div>
                        </div>
                    </div>
                    <!-- /.row (nested) -->
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Entry Information
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-12">
                            
                                <div class="form-groupcol-lg-offset-2 col-lg-8 col-lg-offset-2">
                                    
                                    <select class="form-control" name="department_id">
                                        <option value="">-- Select Department --</option>
                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($department->id); ?>" <?php if(old('department_id') == $department->id): ?> selected <?php endif; ?>><?php echo e($department->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <br>
                                <br>
                                <div style="padding:0px 150px 0px 150px">
                                    <hr>
                                </div>
                                <div class="col-md-6">
                                    <?php $fields = ['punctuality', 'professionalism', 'innovation', 'respect', 'communication',]?>
                                    <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <div class="form-group">
                                            <label><?php echo e(ucfirst($field)); ?></label>
                                            <select class="form-control" name="<?php echo e($field); ?>" required>
                                                <option value="">Select Score</option>
                                                <?php for($i = 1; $i < 6; $i++): ?>
                                                    <option vlaue="<?php echo e($i); ?>" <?php if(old($field) == $i): ?> selected <?php endif; ?>><?php echo e($i); ?></option>
                                                <?php endfor; ?>
                                            </select>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                                <div class="col-md-6">
                                    <?php $fields = ['management', 'leadership', 'delivery', 'inclusiveness', 'appearance',]?>
                                    <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <div class="form-group">
                                            <label><?php echo e(ucfirst($field)); ?></label>
                                            <select class="form-control" name="<?php echo e($field); ?>" required>
                                                <option value="">Select Score</option>
                                                <?php for($i = 1; $i < 6; $i++): ?>
                                                    <option vlaue="<?php echo e($i); ?>" <?php if(old($field) == $i): ?> selected <?php endif; ?>><?php echo e($i); ?></option>
                                                <?php endfor; ?>
                                            </select>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                
                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                    <button type="reset" class="btn btn-default">Reset</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- /.row (nested) -->
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-12 -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\ifeanyi_project\resources\views/create.blade.php ENDPATH**/ ?>