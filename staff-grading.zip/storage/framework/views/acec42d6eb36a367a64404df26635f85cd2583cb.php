<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Startmin - Bootstrap Admin Theme</title>

        <!-- Bootstrap Core CSS -->
        <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="<?php echo e(asset('css/metisMenu.min.css')); ?>" rel="stylesheet">

        <!-- DataTables CSS -->
        <link href="<?php echo e(asset('css/dataTables/dataTables.bootstrap.css')); ?>" rel="stylesheet">

        <!-- DataTables Responsive CSS -->
        <link href="<?php echo e(asset('css/dataTables/dataTables.responsive.css')); ?>" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="<?php echo e(asset('css/startmin.css')); ?>" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
    </head>

    <body>
        <div id="wrapper">
            <!-- Navigation -->
            <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <div class="navbar-header">
                    <a class="navbar-brand" href="index.html">Staff Grading</a>
                </div>

                

                <ul class="nav navbar navbar-top-links">
                    <li><a href="<?php echo e(route('departments.index')); ?>"><i class="fa fa-home fa-fw"></i> Departments </a></li>
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="fa fa-pencil fa-fw"></i> Entries <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu dropdown-user">
                            <li><a href="<?php echo e(route('entries.index')); ?>"><i class="fa fa-eye fa-fw"></i>View Entries</a>
                            </li>
                            <li class="divider"></li>
                            <li><a href="<?php echo e(route('entries.create')); ?>"><i class="fa fa-plus fa-fw"></i> Add Entries</a>
                            </li>
                            
                            
                        </ul>
                    </li>
                </ul>
                <!-- /.navbar-top-links -->

                
                <!-- /.navbar-static-side -->
            </nav>

            <div id="page-wrapper" style="margin:auto">
                <div class="container">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->
        </div>
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="../js/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="../js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="../js/metisMenu.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="../js/startmin.js"></script>
    </body>
</html>
<?php /**PATH C:\Users\user\Desktop\ifeanyi_project\resources\views/layouts/master.blade.php ENDPATH**/ ?>